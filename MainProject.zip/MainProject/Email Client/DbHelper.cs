﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Data;
using System.Data.SqlClient;

namespace Email_Client
{
    public static class DbHelper
    {
        public static readonly SqlConnection _conn = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["ConnString"].ToString());
        public static int uId = 0;
        public static string emailId = "";
        public static string pass = "";
        public static string popServer = "";
        public static string popPort = "";
        public static string smtpServer = "";
        public static string smtpPort = "";
    }
}
