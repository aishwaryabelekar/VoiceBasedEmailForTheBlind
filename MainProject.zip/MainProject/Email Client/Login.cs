﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;
using SpeechLib;
using System.Speech.Recognition;


namespace Email_Client
{
    public partial class Login : Form
    {
        SpeechVoiceSpeakFlags my_Spflag = SpeechVoiceSpeakFlags.SVSFlagsAsync; // declaring and initializing Speech Voice Flags
        SpVoice my_Voice = new SpVoice();
        SpVoice vox = new SpVoice();//declaring and initializing SpVoice Class
        int sp_Rate = 0, sp_Volume = 70;

        public Login()
        {
            InitializeComponent();
        }

        private void linkLabel1_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
        {
            Registration reg = new Registration();
            this.Hide();
            reg.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            //SqlConnection conn = new SqlConnection(System.Configuration.ConfigurationSettings.AppSettings["ConnString"].ToString());
            SqlCommand cmdSelect = new SqlCommand("Select uId, EmailId, password, popServer, popPort, smtpServer, smtpPort from UserMaster where EmailId=@u and Password=@p", DbHelper._conn);
            cmdSelect.Parameters.AddWithValue("@u", txtUsername.Text);
            cmdSelect.Parameters.AddWithValue("@p", txtPassword.Text);
            SqlDataAdapter da = new SqlDataAdapter(cmdSelect);
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                DbHelper.emailId = dt.Rows[0]["EmailId"].ToString();
                DbHelper.pass = dt.Rows[0]["password"].ToString();
                DbHelper.popServer = dt.Rows[0]["popServer"].ToString();
                DbHelper.popPort = dt.Rows[0]["popPort"].ToString();
                DbHelper.smtpServer = dt.Rows[0]["smtpServer"].ToString();
                DbHelper.smtpPort = dt.Rows[0]["smtpPort"].ToString();
                EmailClient ec = new EmailClient();
                this.Hide();
                ec.Show();
            }
            else
            {
                
                MessageBox.Show("Invalid Username and Password");
                txtPassword.Text = "";
            }
        }

        private void txtUsername_Click(object sender, EventArgs e)
        {
            
        }

        private void txtPassword_Click(object sender, EventArgs e)
        {
           
        }

        private void button1_Click(object sender, EventArgs e)
        {
            my_Voice.Speak(txtUsername.Text, my_Spflag);
            my_Voice.Volume = sp_Volume;
            my_Voice.Rate = sp_Rate;
        }


    }
}
