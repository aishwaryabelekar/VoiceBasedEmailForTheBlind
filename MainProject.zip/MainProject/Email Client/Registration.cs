﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using System.Data;
using System.Data.SqlClient;

namespace Email_Client
{
    public partial class Registration : Form
    {
        public Registration()
        {
            InitializeComponent();
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            SqlCommand cmdInsert = new SqlCommand("insert into UserMaster(EmailId, password, popServer, popPort, smtpServer, smtpPort)values(@EmailId, @password, @popServer, @popPort, @smtpServer, @smtpPort)", DbHelper._conn);
            cmdInsert.Parameters.AddWithValue("@EmailId", txtEmail.Text);
            cmdInsert.Parameters.AddWithValue("@password", txtPassword.Text);
            cmdInsert.Parameters.AddWithValue("@popServer", txtpopServer.Text);
            cmdInsert.Parameters.AddWithValue("@popPort", txtPopPort.Text);
            cmdInsert.Parameters.AddWithValue("@smtpServer", txtSmtpServer.Text);
            cmdInsert.Parameters.AddWithValue("@smtpPort", txtSmtpPort.Text);
            DbHelper._conn.Open();
            cmdInsert.ExecuteNonQuery();
            DbHelper._conn.Close();
            MessageBox.Show("Account Create Successfully");
            this.Hide();
            Login l = new Login();
            l.Show();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Login l = new Login();
            this.Hide();
            l.Show();
        }

        private void txtEmail_Click(object sender, EventArgs e)
        {
            
        }

        private void txtPassword_Click(object sender, EventArgs e)
        {
            
        }
    }
}
